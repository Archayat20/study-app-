import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import SessionClock from "@/components/dj-session/SessionClock";
import ActivitySelector from "@/components/dj-session/ActivitySelector";
import ImageCarousel from "@/components/dj-session/ImageCarousel";
import StatusBars from "@/components/dj-session/StatusBars";
import NowPlayingBar from "@/components/dj-session/NowPlayingBar";


import  AudioPlayer from "@/components/dj-session/audioplayer"
import { audioLibrary, Track } from "@/lib/audioLibrary";

const DJSession = () => {
  //Used to show time elapsed
  const [sessionStartTime] = useState(Date.now());


  const folder = audioLibrary[0];
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const currentTrack = folder.tracks[currentIndex];
  const [hasInteracted, setHasInteracted] = useState(false);

  const onUserInteract = () => {
    setHasInteracted(true);
  };
  
  const [activity, setActivity] = useState("study");
  
  // These would come from backend calls
  const [hearts, setHearts] = useState(4);
  const [maxHearts] = useState(5);
  const [hunger, setHunger] = useState(7);
  const [maxHunger] = useState(10);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[150px] animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-secondary/10 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '1.5s' }} />

      <div className="container mx-auto px-3 lg:px-4 py-6 flex flex-col">
        {/* Top Section: Clock + Mood Legend */}
        <div className="flex justify-start lg:justify-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex-1 flex flex-col items-center"
          >
            <SessionClock sessionStartTime={sessionStartTime} />
          </motion.div>
        </div>

        {/* Activity Selector */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex justify-start lg:justify-center mb-8"
        >
          <ActivitySelector value={activity} onChange={setActivity} />
        </motion.div>

        <button onClick={onUserInteract}>Start DJ Session</button>

        {/* Main Content: Image Carousel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="grow flex flex flex-col items-center justify-start lg:justify-center mb-8"
        >
          <ImageCarousel activity={activity}/>

        </motion.div>


        {/* Now Playing Bar */}
<AudioPlayer
  src={currentTrack.src}
  isPlaying={isPlaying}
  autoPlayAfterInteract={hasInteracted}
  onProgress={(time, duration) => {
    // update NowPlayingBar state
    // (use useState or useReducer)
  }}
  onEnded={() => {
    setCurrentIndex((i) => (i + 1) % folder.tracks.length);
  }}
/>

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.5, delay: 0.6 }}
>
  <NowPlayingBar
    song={{
      title: currentTrack.title,
      artist: currentTrack.artist,
      album: "Temporary",
      duration: 0,
      currentTime: 0,
    }}
    isPlaying={isPlaying}
    onPlay={() => setIsPlaying(true)}
    onPause={() => setIsPlaying(false)}
    onNext={() =>
      setCurrentIndex((i) => (i + 1) % folder.tracks.length)
    }
    onPrev={() =>
      setCurrentIndex((i) =>
        i === 0 ? folder.tracks.length - 1 : i - 1
      )
    }
  />
</motion.div>
      </div>
    </div>
  );
};

export default DJSession;
